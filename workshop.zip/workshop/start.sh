#!/bin/bash
echo -e '\e[1;35m'
docker-compose up --build -d
echo -e '\e[0m'
echo -e 'EXPLOITATION'
echo -e ''
echo -e 'Visit \e[32mhttp://ip:port/ \e[0mto access the vulnerable web application'