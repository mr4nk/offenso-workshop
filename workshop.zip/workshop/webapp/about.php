<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - EvilCorp IT Consultancy</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-image: url('pxfuel(1).jpg'); /* Replace 'background-image.jpg' with the path to your background image */
            background-size: cover;
            background-repeat: no-repeat;
            color: #fff; /* Set font color to white */
            font-family: 'Courier New', Courier, monospace; /* Set font family to resemble terminal font */
            margin: 0;
            padding: 0;
            text-align: center;
        }
        header {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px 0;
        }
        header h1 {
            font-size: 2.5em;
            margin: 0;
            color: #00ff00;
        }
        header nav ul {
            list-style: none;
            padding: 0;
        }
        header nav ul li {
            display: inline-block;
            margin-right: 20px;
        }
        header nav ul li a {
            text-decoration: none;
            color: #00ff00;
            transition: color 0.3s;
        }
        header nav ul li a:hover {
            color: #fff;
        }
        .content {
            padding: 50px 0;
        }
        footer {
            background-color: rgba(0, 0, 0, 0.7);
            color: #00ff00;
            padding: 20px 0;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
        @media screen and (-webkit-min-device-pixel-ratio:0) {
            footer {
                position: relative;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>EvilCorp IT Consultancy</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <section class="content">
        <div class="container">
            <h2>About Us</h2>
            <p>EvilCorp is a leading IT consultancy firm specializing in providing innovative solutions to businesses worldwide. Our team of experts is dedicated to delivering high-quality services tailored to meet your unique requirements.</p>
            <p>We believe in leveraging cutting-edge technologies and industry best practices to help our clients stay ahead in today's competitive market.</p>
            <p>With a focus on client satisfaction and continuous improvement, we strive to exceed expectations and deliver value-added solutions that drive business growth.</p>
            <p>At EvilCorp, we are committed to fostering a culture of collaboration, creativity, and excellence. Our talented professionals bring a wealth of experience and expertise to every project, ensuring optimal results and maximum impact.</p>
            <p>Whether you're a startup looking to disrupt the market or an established enterprise seeking to innovate and optimize your operations, EvilCorp is your trusted partner for all your IT consultancy needs.</p>
        </div>
    </section>
    <footer>
        <div class="container">
            <p>&copy; 2024 EvilCorp IT Consultancy. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
