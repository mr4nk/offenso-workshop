document.addEventListener('DOMContentLoaded', function() {
    const usernames = ['john_doe', 'alice_smith', 'bob_jackson'];

    function getRandomUsername() {
        const randomIndex = Math.floor(Math.random() * usernames.length);
        return usernames[randomIndex];
    }

    function generateProfileURL() {
        const username = getRandomUsername();
        const profileURL = '/profile.php?user=' + encodeURIComponent(username);
        return profileURL;
    }

    console.log('Generated Profile URL:', generateProfileURL());
});
