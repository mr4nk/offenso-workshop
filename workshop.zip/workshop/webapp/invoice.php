<?php
session_start();

// Check if session variable is set
if (!isset($_SESSION['username'])) {
    // Redirect to login page
    header("Location: login.php");
    exit();
}
// Logout functionality
if (isset($_GET['logout'])) {
    // Destroy the session
    session_destroy();
}

// Include database connection
include 'db_connection.php';

// Upload file
if (isset($_POST['submit'])) {
    $file_name = $_FILES['file']['name'];
    $file_temp = $_FILES['file']['tmp_name'];
    $file_size = $_FILES['file']['size'];
    $file_error = $_FILES['file']['error'];

    if ($file_error === 0) {
        $file_destination = 'uploads/' . $file_name;
        move_uploaded_file($file_temp, $file_destination);

        $sql = "INSERT INTO invoices (file_name, file_path) VALUES ('$file_name', '$file_destination')";
        mysqli_query($conn, $sql);
    }
}

// Search for files
if (isset($_GET['search_query'])) {
    $search_query = $_GET['search_query'];
    $sql = "SELECT * FROM invoices WHERE file_name LIKE '%$search_query%'";
} else {
    $sql = "SELECT * FROM invoices";
}

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice - EvilCorp IT Consultancy</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-image: url('pxfuel(1).jpg'); /* Replace 'background-image.jpg' with the path to your background image */
            background-size: cover;
            background-repeat: no-repeat;
            color: #fff; /* Set font color to white */
            font-family: 'Courier New', Courier, monospace; /* Set font family to resemble terminal font */
            margin: 0;
            padding: 0;
            text-align: center;
        }
        header {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px 0;
        }
        header h1 {
            font-size: 2.5em;
            margin: 0;
            color: #00ff00;
        }
        header nav ul {
            list-style: none;
            padding: 0;
        }
        header nav ul li {
            display: inline-block;
            margin-right: 20px;
        }
        header nav ul li a {
            text-decoration: none;
            color: #00ff00;
            transition: color 0.3s;
        }
        header nav ul li a:hover {
            color: #fff;
        }
        .container {
            margin-top: 50px;
        }
        .upload-form {
            margin-bottom: 20px;
        }
        .table th {
            background-color: rgba(0, 0, 0, 0.7);
            color: #00ff00;
        }
        .table td, .table th {
            border: 1px solid #dee2e6;
            padding: 8px;
        }
        .table td a {
            color: #00ff00; /* File names in green */
            text-decoration: none;
        }
        .table td a:hover {
            text-decoration: underline;
        }
        footer {
            background-color: rgba(0, 0, 0, 0.7);
            color: #00ff00;
            padding: 10px 0; /* Adjusted footer size */
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>EvilCorp IT Consultancy</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="invoice.php">Upload Invoice</a></li>
                    <a href="?logout=true" class="btn btn-danger logout">Logout</a>
                </ul>
            </nav>
        </div>
    </header>
    <div class="container">
        <div class="upload-form">
            <h2>Upload Invoice</h2>
            <form action="invoice.php" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <input type="file" class="form-control-file" name="file" required>
                </div>
                <button type="submit" name="submit" class="btn btn-primary">Upload</button>
            </form>
        </div>

        <h2>View Invoices</h2>
        <form action="invoice.php" method="get" class="mb-3">
            <div class="input-group">
                <input type="text" class="form-control" name="search_query" placeholder="Search file names">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-outline-secondary">Search</button>
                </div>
            </div>
        </form>

        <table class="table">
            <thead>
                <tr>
                    <th>File Name</th>
                    <th>View</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td style="color: #00ff00;"><?php echo $row['file_name']; ?></td> <!-- File names in green -->
                        <td><a href="<?php echo $row['file_path']; ?>" target="_blank">View</a></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
