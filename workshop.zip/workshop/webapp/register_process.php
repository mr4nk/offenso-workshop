<?php
// Include your database connection file
require_once 'db_connection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize the input
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $company_email = trim($_POST['company_email']);
    $address = trim($_POST['address']);
    $company_name = trim($_POST['company_name']);
    $phone_number = trim($_POST['phone_number']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Prepare a select statement to check if the username exists
    $sql = "SELECT id FROM users WHERE username = ?";
    
    if ($stmt = mysqli_prepare($conn, $sql)) {
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "s", $param_username);

        // Set parameters
        $param_username = $username;

        // Attempt to execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_store_result($stmt);
            
            if (mysqli_stmt_num_rows($stmt) == 1) {
                echo "This username is already taken. Please choose another one.";
            } else {
                // Username doesn't exist, insert new user
                
                // Prepare an insert statement
                $sql = "INSERT INTO users (first_name, last_name, company_email, address, company_name, phone_number, username, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                
                if ($stmt = mysqli_prepare($conn, $sql)) {
                    // Bind variables to the prepared statement as parameters
                    mysqli_stmt_bind_param($stmt, "ssssssss", $param_first_name, $param_last_name, $param_company_email, $param_address, $param_company_name, $param_phone_number, $param_username, $param_password);

                    // Set parameters
                    $param_first_name = $first_name;
                    $param_last_name = $last_name;
                    $param_company_email = $company_email;
                    $param_address = $address;
                    $param_company_name = $company_name;
                    $param_phone_number = $phone_number;
                    $param_username = $username;
                    // Create a password hash
                    $param_password = password_hash($password, PASSWORD_DEFAULT);

                    // Attempt to execute the prepared statement
                    if (mysqli_stmt_execute($stmt)) {
                        echo "Registration successful. <a href='login.php'>Click here to login</a>.";
                    } else {
                        echo "Something went wrong. Please try again later.";
                    }
                }
            }
        } else {
            echo "Oops! Something went wrong. Please try again later.";
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($conn);
} else {
    // Not a POST request, redirect to the registration form
    header("Location: register.php");
    exit();
}
?>
