<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services - EvilCorp IT Consultancy</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-image: url('pxfuel(1).jpg'); /* Replace 'background-image.jpg' with the path to your background image */
            background-size: cover;
            background-repeat: no-repeat;
            color: #fff; /* Set font color to white */
            font-family: 'Courier New', Courier, monospace; /* Set font family to resemble terminal font */
            margin: 0;
            padding: 0;
            text-align: center;
        }
        header {
            background-color: rgba(0, 0, 0, 0.7);
            padding: 20px 0;
        }
        header h1 {
            font-size: 2.5em;
            margin: 0;
            color: #00ff00;
        }
        header nav ul {
            list-style: none;
            padding: 0;
        }
        header nav ul li {
            display: inline-block;
            margin-right: 20px;
        }
        header nav ul li a {
            text-decoration: none;
            color: #00ff00;
            transition: color 0.3s;
        }
        header nav ul li a:hover {
            color: #fff;
        }
        .content {
            padding: 50px 0;
        }
        footer {
            background-color: rgba(0, 0, 0, 0.7);
            color: #00ff00;
            padding: 20px 0;
            position: absolute;
            bottom: 0;
            width: 100%;
        }
        @media screen and (-webkit-min-device-pixel-ratio:0) {
            footer {
                position: relative;
            }
        }
        .card {
            background-color: rgba(0, 0, 0, 0.5);
            border: 2px solid rgba(255, 255, 255, 0.2); /* Light border */
            color: #fff;
            margin-bottom: 20px; /* Add margin to create space between cards */
        }
        .card-title {
            color: #00ff00; /* Green color for card titles */
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>EvilCorp IT Consultancy</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <section class="content">
        <div class="container">
            <h2>Our Services</h2>
            <p>Explore our range of IT consultancy services tailored to meet your business needs:</p>
            <div class="row justify-content-center">
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Custom Software Development</h5>
                            <p class="card-text">We develop custom software solutions to address your specific business requirements. Our team of experts utilizes the latest technologies to create efficient and scalable software products.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Cloud Computing Solutions</h5>
                            <p class="card-text">Leverage the power of cloud computing for scalability, flexibility, and cost-efficiency. Our cloud solutions are designed to optimize your business operations and drive growth.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">IT Infrastructure Management</h5>
                            <p class="card-text">Efficiently manage and optimize your IT infrastructure for improved performance and reliability. Our comprehensive management services ensure smooth operation and minimal downtime.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Cybersecurity Solutions</h5>
                            <p class="card-text">Protect your digital assets and safeguard your business against cyber threats and vulnerabilities. Our cybersecurity experts provide robust solutions to ensure the security of your IT infrastructure.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Data Analytics Services</h5>
                            <p class="card-text">Unlock valuable insights from your data to make informed business decisions and drive growth. Our data analytics solutions help you extract actionable intelligence from large datasets.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Network Infrastructure Solutions</h5>
                            <p class="card-text">Design, implement, and manage robust network infrastructures to support your business operations. Our network solutions ensure reliable connectivity and efficient data transfer.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer>
        <div class="container">
            <p>&copy; 2024 EvilCorp IT Consultancy. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
