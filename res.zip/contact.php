<?php

require 'db.php';

$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

if (!$name || !$email || !$message) {
    http_response_code(400);
    exit;
}

$sql = "INSERT INTO contacts (name, email, message) VALUES ('$name', '$email', '$message')";
mysqli_query($conn, $sql);

$conn->close();
exit;
?>
