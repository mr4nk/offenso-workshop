<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Gourmet Delight</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <style>
    body { font-family: 'Poppins', sans-serif; }
    h1, h2, h3, h4 { font-family: 'Playfair Display', serif; }
  </style>
</head>
<body class="bg-white text-gray-800">
  <!-- Navbar -->
  <header class="bg-gradient-to-r from-red-700 to-yellow-500 text-white p-4 shadow-lg sticky top-0 z-50">
    <div class="container mx-auto flex justify-between items-center">
      <h1 class="text-3xl font-bold">Gourmet Delight</h1>
      <nav class="space-x-6 font-medium">
        <a href="#home" class="hover:underline">Home</a>
        <a href="#about" class="hover:underline">About</a>
        <a href="#menu" class="hover:underline">Menu</a>
        <a href="#team" class="hover:underline">Team</a>
        <a href="#reservation" class="hover:underline">Reservation</a>
        <a href="#contact" class="hover:underline">Contact</a>
      </nav>
    </div>
  </header>

  <!-- Hero Section -->
  <section id="home" class="h-screen bg-cover bg-center relative" style="background-image: url('https://source.unsplash.com/1600x900/?fine-dining,restaurant');">
    <div class="absolute inset-0 bg-black bg-opacity-50 flex flex-col items-center justify-center text-center p-4" data-aos="fade-up">
      <h2 class="text-5xl text-white font-bold mb-4">Experience Fine Dining</h2>
      <p class="text-white text-lg max-w-xl">At Gourmet Delight, we serve passion on a plate. Savor flavors crafted by master chefs in a luxurious ambiance.</p>
      <a href="#menu" class="mt-6 bg-yellow-400 text-black font-semibold px-6 py-3 rounded shadow hover:bg-yellow-500 transition">Explore Menu</a>
    </div>
  </section>

  <!-- About Section -->
  <section id="about" class="py-20 bg-gray-100" data-aos="fade-up">
    <div class="container mx-auto px-4 text-center">
      <h2 class="text-4xl font-bold mb-6">About Us</h2>
      <p class="text-lg max-w-3xl mx-auto">Gourmet Delight brings the finest culinary traditions to your plate. With locally sourced ingredients, elegant interiors, and expert chefs, we create an unforgettable dining experience for every guest.</p>
    </div>
  </section>

  <!-- Menu Section -->
  <section id="menu" class="py-20" data-aos="fade-up">
    <div class="container mx-auto px-4 text-center">
      <h2 class="text-4xl font-bold mb-6">Our Menu</h2>
      <div class="grid md:grid-cols-3 gap-8">
        <div class="bg-white shadow-lg p-6 rounded">
          <h3 class="text-xl font-semibold mb-2">Grilled Salmon</h3>
          <p>Fresh Atlantic salmon served with lemon butter sauce and seasonal vegetables.</p>
        </div>
        <div class="bg-white shadow-lg p-6 rounded">
          <h3 class="text-xl font-semibold mb-2">Truffle Risotto</h3>
          <p>Creamy risotto with wild mushrooms, white truffle oil, and parmesan shavings.</p>
        </div>
        <div class="bg-white shadow-lg p-6 rounded">
          <h3 class="text-xl font-semibold mb-2">Chocolate Lava Cake</h3>
          <p>Decadent chocolate cake with a molten center, served with vanilla bean ice cream.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Chefs Section -->
  <section id="team" class="py-20 bg-gray-100" data-aos="fade-up">
    <div class="container mx-auto px-4 text-center">
      <h2 class="text-4xl font-bold mb-6">Meet Our Team</h2>
      <div class="grid md:grid-cols-3 gap-8">
        <div>
          <h3 class="text-xl font-semibold">Richard Robert</h3>
          <p>General Manager</p>
        </div>
        <div>
        <h3 class="text-xl font-semibold">Aiko Tanaka</h3>
          <p>Human Resource Manager</p>
        </div>
        <div>
        <h3 class="text-xl font-semibold">George Rossi</h3>
          <p>System Admin</p>
        </div>
          <div>
          <h3 class="text-xl font-semibold">Chef Liam Smith</h3>
          <p>Specialist in gourmet desserts and French patisserie.</p>
        </div>
          <div>
          <h3 class="text-xl font-semibold">Chef Bob Rossi</h3>
          <p>Master of Italian cuisine and fine dining experiences.</p>
        </div>
          <div>
          <h3 class="text-xl font-semibold">Chef Smith Martin</h3>
          <p>Specialist in gourmet desserts and French patisserie.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Reservation Section -->
  <section id="reservation" class="py-20" data-aos="zoom-in">
    <div class="container mx-auto px-4 text-center">
      <h2 class="text-4xl font-bold mb-6">Make a Reservation</h2>
      <p class="text-lg max-w-xl mx-auto mb-10">Reserve your table in advance to enjoy a hassle-free fine dining experience at Gourmet Delight.</p>
      <form id="reservation-form" class="max-w-xl mx-auto space-y-4">
        <input type="text" name="name" placeholder="Full Name" class="w-full border border-gray-300 p-3 rounded" required>
        <input type="email" name="email" placeholder="Email Address" class="w-full border border-gray-300 p-3 rounded" required>
        <input type="tel" name="phone" placeholder="Phone Number" class="w-full border border-gray-300 p-3 rounded" required>
        <input type="date" name="date" class="w-full border border-gray-300 p-3 rounded" required>
        <input type="time" name="time" class="w-full border border-gray-300 p-3 rounded" required>
        <select name="guests" class="w-full border border-gray-300 p-3 rounded" required>
          <option value="">Number of Guests</option>
          <option>1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5+</option>
        </select>
        <button type="submit" class="bg-yellow-400 text-black font-semibold px-6 py-3 rounded shadow hover:bg-yellow-500 transition">Book Now</button>
      </form>
      <div id="reservation-status" class="text-green-600 font-medium mt-4"></div>
    </div>
  </section>

<!-- Contact Section -->
  <section id="contact" class="py-20" data-aos="fade-up">
    <div class="container mx-auto px-4 text-center">
      <h2 class="text-4xl font-bold mb-6">Get In Touch</h2>
      <p class="text-lg max-w-xl mx-auto mb-10">We’d love to hear from you! Whether you're booking a table or have a question, reach out below.</p>
	<form id="contact-form" class="max-w-lg mx-auto space-y-4">
	  <input type="text" name="name" placeholder="Your Name" class="w-full border border-gray-300 p-3 rounded" required>
	  <input type="email" name="email" placeholder="Your Email" class="w-full border border-gray-300 p-3 rounded" required>
	  <textarea name="message" placeholder="Your Message" rows="5" class="w-full border border-gray-300 p-3 rounded" required></textarea>
	  <button type="submit" class="bg-gradient-to-r from-yellow-400 to-red-500 text-white font-semibold px-6 py-3 rounded shadow hover:from-yellow-500 hover:to-red-600 transition">Send Message</button>
	</form>
	<script>
	function validateForm() {
	  const name = document.getElementById("name").value.trim();
	  const email = document.getElementById("email").value.trim();
	  const message = document.getElementById("message").value.trim();

	  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

	  if (name.length < 3) {
	    alert("Name must be at least 3 characters.");
	    return false;
	  }

	  if (!emailPattern.test(email)) {
	    alert("Enter a valid email address.");
	    return false;
	  }

	  if (message.length < 5) {
	    alert("Message should be at least 5 characters.");
	    return false;
	  }

	  return true; 
	}
	</script>
      <div class="mt-10 text-gray-600">
        <p>Email: aiko.tanaka@gourmetdelight.com</p>
        <p>Phone: +1 (555) 123-4567</p>
        <p>Location: 123 Culinary Ave, Flavor Town</p>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="bg-gray-900 text-white text-center py-6">
    <p>&copy; 2025 Gourmet Delight. Crafted with passion and flavor.</p>
  </footer>

  <!-- Scripts -->
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
  <script>
    AOS.init();
    document.getElementById('reservation-form').addEventListener('submit', function(e) {
      e.preventDefault();
      const form = e.target;
      const formData = new FormData(form);
      fetch('reservation.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.text())
      .then(data => {
        document.getElementById('reservation-status').innerText = data;
        form.reset();
      })
      .catch(err => {
        document.getElementById('reservation-status').innerText = 'Reservation failed. Please try again.';
      });
    });
    
    document.getElementById('contact-form').addEventListener('submit', function(e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);
  fetch('contact.php', {
    method: 'POST',
    body: formData
  })
  .catch(err => {
  });
  form.reset();
});

  </script>
</body>
</html>
