<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $date = $_POST['date'] ?? '';
    $time = $_POST['time'] ?? '';
    $guests = $_POST['guests'] ?? '';

    if (!$name || !$email || !$phone || !$date || !$time || !$guests) {
        echo 'Please fill in all required fields correctly.';
        exit;
    }


    echo "Thank you, $name! Your reservation for $guests guest(s) on $date at $time is confirmed.";
} else {
    echo "Invalid request.";
}
?>
