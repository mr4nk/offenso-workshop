<?php
session_start();
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows == 1) {
        $stmt->bind_result($id, $hashed_password);
        $stmt->fetch();
        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
            header("Location: home.php");
            exit;
        } else {
            echo "Invalid credentials.";
        }
    } else {
        echo "User not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 h-screen flex items-center justify-center">
  <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
    <h2 class="text-2xl font-bold mb-6 text-center text-red-600">Login</h2>
    <?php if (!empty($error)): ?>
      <div class="mb-4 p-3 bg-red-100 text-red-700 border border-red-300 rounded">
        <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>
    <form action="" method="post" class="space-y-4">
      <input type="email" name="email" placeholder="Username" class="w-full border rounded px-3 py-2" required>
      <input type="password" name="password" placeholder="Password" class="w-full border rounded px-3 py-2" required>
      <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white py-2 rounded transition">Login</button>
    </form>
  </div>
</body>
</html>
