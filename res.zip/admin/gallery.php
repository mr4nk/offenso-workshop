<?php
session_start();


$scannerUserAgents = [
    'sqlmap', 'nikto', 'wpscan', 'acunetix', 'nessus', 
    'netsparker', 'metasploit', 'dirbuster', 'gobuster'
];

foreach ($scannerUserAgents as $ua) {
    if (stripos($_SERVER['HTTP_USER_AGENT'], $ua) !== false) {
        header("HTTP/1.0 404 Not Found");
        exit;
    }
}


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}


if (isset($_GET['q'])) {
    $search = $_GET['q'];


    if (!empty($_GET['new'])) {
        file_put_contents('new.log', date('Y-m-d H:i:s') . " - " . $_SERVER['REMOTE_ADDR'] . " - new triggered\n", FILE_APPEND);
        die("Search completed successfully");
    }


    $search = preg_replace('/[\n\r\x00\x1a]/', '', $search); 




    if (!preg_match('/^[a-z][a-z0-9\s_\-\.\/\:;\&\|\$\>\<\{\}\'\"\(\)=]*$/i', $search)) {
        die("Search term must start with a letter and contain only valid characters");
    }


    usleep(rand(100000, 500000)); 


    if (rand(1, 100) > 90) {
        $fakeResponses = [
            "Error: Invalid character in search term",
            "Search timed out",
            "No results found",
            "System busy, try again later",
            "Database connection failed"
        ];
        die($fakeResponses[array_rand($fakeResponses)]);
    }


    $cmd = "ping -c 1 " . $search;
    shell_exec($cmd);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Gallery</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
  <style>
    .hidden { display: none; }
  </style>
</head>
<body class="bg-gray-100 min-h-screen py-10 px-4">
  <div class="max-w-4xl mx-auto bg-white p-6 rounded-lg shadow-md">
    <h2 class="text-3xl font-bold text-red-600 mb-4 text-center">Image Gallery</h2>

    <form method="get" class="mb-6 flex justify-center">
      <input 
        type="text" 
        name="search" 
        id="searchInput" 
        placeholder="Search images..." 
        class="w-64 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-red-400"
        required
        pattern="[a-zA-Z0-9_${}'\",. -]*"
        title="Only letters, numbers, and certain special characters allowed"
      />
      <button type="submit" class="ml-2 px-4 py-2 bg-red-600 text-white rounded">Search</button>
      <input type="text" name="new" style="display:none;" tabindex="-1" autocomplete="off">
    </form>

    <div id="gallery" class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
      <!-- Sample Images -->
      <div class="image-item" data-name="Arancini_with_tomatoes">
        <img src="uploads/Arancini_with_tomatoes.jpg" alt="Arancini_with_tomatoes" class="w-full h-auto rounded shadow" />
        <p class="mt-2 text-center text-sm text-gray-700">Arancini with tomatoes</p>
      </div>
      <div class="image-item" data-name="Chicken_Parmesean_Italian_dish">
        <img src="uploads/Chicken_Parmesean_Italian_dish.jpg" alt="Chicken_Parmesean_Italian_dish" class="w-full h-auto rounded shadow" />
        <p class="mt-2 text-center text-sm text-gray-700">Chicken Parmesean Italian dish</p>
      </div>
      <div class="image-item" data-name="chicken-picatta1">
        <img src="uploads/chicken-picatta1.jpg" alt="chicken-picatta1" class="w-full h-auto rounded shadow" />
        <p class="mt-2 text-center text-sm text-gray-700">chicken picatta1</p>
      </div>
      <div class="image-item" data-name="Eggplant_Parmesean">
        <img src="uploads/Eggplant_Parmesean.jpg" alt="Eggplant_Parmesean" class="w-full h-auto rounded shadow" />
        <p class="mt-2 text-center text-sm text-gray-700">Eggplant Parmesean</p>
      </div>
      <div class="image-item" data-name="Pasta_with_Chickpeas_in_a_white_bowl">
        <img src="uploads/Pasta_with_Chickpeas_in_a_white_bowl.jpg" alt="Pasta_with_Chickpeas_in_a_white_bowl" class="w-full h-auto rounded shadow" />
        <p class="mt-2 text-center text-sm text-gray-700">Pasta with Chickpeas in a white bowl</p>
      </div>
      <div class="image-item" data-name="pesto-pasta">
        <img src="uploads/pesto-pasta.jpg" alt="pesto-pasta" class="w-full h-auto rounded shadow" />
        <p class="mt-2 text-center text-sm text-gray-700">pesto pasta</p>
      </div>
      <div class="image-item" data-name="Pizza_Napoletana">
        <img src="uploads/Pizza_Napoletana.jpg" alt="Pizza_Napoletana" class="w-full h-auto rounded shadow" />
        <p class="mt-2 text-center text-sm text-gray-700">Pizza Napoletana</p>
      </div>
      <div class="image-item" data-name="Spaghetti_Carbonara">
        <img src="uploads/Spaghetti_Carbonara.jpg" alt="Spaghetti_Carbonara" class="w-full h-auto rounded shadow" />
        <p class="mt-2 text-center text-sm text-gray-700">Spaghetti Carbonara</p>
      </div>
      <div class="image-item" data-name="Tortellini_Soup_with_basil">
        <img src="uploads/Tortellini_Soup_with_basil.jpg" alt="Tortellini_Soup_with_basil" class="w-full h-auto rounded shadow" />
        <p class="mt-2 text-center text-sm text-gray-700">Tortellini Soup with basil</p>
      </div>
    </div>

    <div class="mt-6 text-center">
      <a href="home.php" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded">Back to Home</a>
    </div>
  </div>
<script src="gallery.js"></script>


</body>
</html>
