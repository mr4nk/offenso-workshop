<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>404 - Page Not Found</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
  <div class="text-center p-8 bg-white shadow-lg rounded-lg">
    <h1 class="text-6xl font-extrabold text-red-600 mb-4">404</h1>
    <h2 class="text-2xl font-semibold text-gray-800 mb-2">Page Not Found</h2>
    <p class="text-gray-600 mb-6">Oops! The page you're looking for doesn't exist.</p>
    
    <div class="mb-4 text-sm text-gray-500 italic">
      If you think this is an error, please <a href="home.php" class="text-red-600 hover:underline">contact the admin</a>.
    </div>
    
    <a href="gallery.php" class="inline-block px-6 py-2 bg-red-600 text-white rounded hover:bg-red-700 transition">Back to Gallery</a>
  </div>
</body>
</html>
