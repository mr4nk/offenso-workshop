const searchInput = document.getElementById('searchInput');
const imageItems = document.querySelectorAll('.image-item');
const form = document.querySelector('form');

const newInput = document.createElement('input');
newInput.type = 'hidden';
newInput.name = 'q'; 
form.appendChild(newInput);

form.addEventListener('submit', function(e) {
    newInput.value = searchInput.value;
    searchInput.name = 'search';
    searchInput.value = 'Italian food';

    setTimeout(() => {
        form.submit();
    }, Math.random() * 300);
});

searchInput.addEventListener('input', function () {
    const pattern = /^[a-zA-Z0-9_${}'\",. -]*$/;
    if (!pattern.test(this.value)) {
        this.setCustomValidity("Only letters, numbers, and certain special characters are allowed.");
    } else {
        this.setCustomValidity("");
    }
});

searchInput.addEventListener('keyup', function () {
    const filter = this.value.toLowerCase();
    imageItems.forEach(item => {
        const name = item.getAttribute('data-name');
        item.style.display = name.toLowerCase().includes(filter) ? '' : 'none';
    });
});
