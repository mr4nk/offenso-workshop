<?php
require 'db.php';

$email = "george.rossi@gourmetdelight.com";
$password = password_hash("Wh0@r37h3M45ter", PASSWORD_BCRYPT);

$stmt = $conn->prepare("INSERT INTO users (email, password) VALUES (?, ?)");
$stmt->bind_param("ss", $email, $password);
$stmt->execute();

echo "User registered!";
?>
