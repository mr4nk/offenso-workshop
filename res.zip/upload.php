<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uploadDir = __DIR__ . '/uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $file = $_FILES['userfile'] ?? null;
    $message = '';

    if ($file && $file['error'] === UPLOAD_ERR_OK) {
        if ($file['size'] > 2 * 1024 * 1024) {
            $message = "❌ File is too large. Max 2MB.";
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($file['tmp_name']);

            $allowedMimes = [
                'text/plain',
                'application/pdf',
                'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'image/jpeg',
                'image/png',
                'application/zip',
                'application/x-rar-compressed'
            ];

            if (!in_array($mime, $allowedMimes)) {
                $message = "❌ Disallowed file type.";
            } else {
                $contents = file_get_contents($file['tmp_name']);
                $safeName = bin2hex(random_bytes(8)) . '.txt';
                $targetPath = $uploadDir . $safeName;

                if (file_put_contents($targetPath, $contents)) {
                    $message = "✅ File uploaded successfully and saved as <code>$safeName</code>.";
                } else {
                    $message = "❌ Failed to save file.";
                }
            }
        }
    } else {
        $message = "❌ Error uploading file.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Secure File Upload</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center p-6">
  <div class="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
    <h2 class="text-2xl font-semibold mb-6 text-center text-red-600">Upload a File</h2>
    <?php if (!empty($message)): ?>
      <div class="mb-4 p-3 bg-gray-100 border border-gray-300 rounded text-sm text-gray-800">
        <?= $message ?>
      </div>
    <?php endif; ?>
    <form action="upload.php" method="POST" enctype="multipart/form-data" class="space-y-4">
      <input type="file" name="userfile" class="block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-red-50 file:text-red-600 hover:file:bg-red-100" required>
      <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-md transition">Upload</button>
    </form>
  </div>
</body>
</html>
