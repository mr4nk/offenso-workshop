<html>
//echo password_hash("Strong@1234", PASSWORD_DEFAULT);
</html>
