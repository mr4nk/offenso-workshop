<?php
session_start();

$storedUsername = 'richard.robert@gourmetdelight.com';
$storedPassword = 'Strong@1234';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Trim inputs to avoid issues with extra spaces
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // Direct string comparison
    if ($username === $storedUsername && $password === $storedPassword) {
        $_SESSION['loggedin'] = true;
        header('Location: upload.php');
        exit;
    } else {
        $error = "Invalid credentials.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 h-screen flex items-center justify-center">
  <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
    <h2 class="text-2xl font-bold mb-6 text-center text-red-600">Login</h2>
    <?php if (!empty($error)): ?>
      <div class="mb-4 p-3 bg-red-100 text-red-700 border border-red-300 rounded">
        <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>
    <form action="" method="post" class="space-y-4" autocomplete="off">
      <input type="text" name="username" placeholder="Username" class="w-full border rounded px-3 py-2" required autofocus>
      <input type="password" name="password" placeholder="Password" class="w-full border rounded px-3 py-2" required>
      <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white py-2 rounded transition">Login</button>
    </form>
  </div>
</body>
</html>
